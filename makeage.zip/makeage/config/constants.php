<?php

return [

    'admin_per_page_limit' => 1,
    'admin_page_limits' => [1, 25, 50, 100]
];
