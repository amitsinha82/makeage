<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
Route::get('/admin', function () {
    return redirect('admin/login');
});
Route::get('admin/login', 'Admin\AdminController@getLogin');
Route::post('admin/login', 'Admin\AdminController@postLogin');
Route::group(['prefix' => 'admin'], function () {
//    Route::post('user/email', 'Admin\AdminController@postTemporaryPassword');

    Route::group(['middleware' => ['Role']], function () {
        Route::get('logout', 'Admin\AdminController@getlogout');
        Route::get('dashboard', 'Admin\AdminController@getDashboard');
        Route::get('school/school-list', 'Admin\SchoolController@getSchoolList');
        Route::get('school/school-list-ajax', 'Admin\SchoolController@getSchoolListAjax');
        Route::get('school-details/{id}', 'Admin\SchoolController@@getSchoolDetails');
    });
});
