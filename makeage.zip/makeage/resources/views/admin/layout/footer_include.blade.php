
<script type="text/javascript" src="{{URL::asset('assets/admin/js/jquery.dataTables.min.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('assets/admin/js/dataTables.responsive.js')}}"></script>